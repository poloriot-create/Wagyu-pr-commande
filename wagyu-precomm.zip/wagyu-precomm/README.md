# Wagyu precomm

A Pen created on CodePen.

Original URL: [https://codepen.io/Riot-Paul/pen/emZMQxp](https://codepen.io/Riot-Paul/pen/emZMQxp).

